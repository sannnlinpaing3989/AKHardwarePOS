AK Hardware POS - Android APK Build

ဒီ ZIP ထဲမှာ Android app source နဲ့ GitHub Actions အလိုအလျောက် APK build workflow ပါပါတယ်။ APK ကို ဒီ ZIP ထဲမှာ အဆင်သင့်ထုတ်ထားတာ မဟုတ်ပါ။

APK ရယူရန် (ကွန်ပျူတာမလိုဘဲ ဖုန်း Browser နဲ့လည်း လုပ်နိုင်သည်):
1. GitHub.com အကောင့်ဝင်/ဖွင့်ပါ။
2. New repository ဖန်တီးပါ။ ဥပမာ ak-hardware-pos (Private လုပ်နိုင်သည်)။
3. ဒီ ZIP ကို ဖြည်ပြီး အထဲက ဖိုင်/ဖိုလ်ဒါအားလုံးကို repository ထဲ Upload files နဲ့ တင်ပါ။ .github ဖိုလ်ဒါပါဝင်ကြောင်း သေချာပါစေ။ Commit changes ကိုနှိပ်ပါ။
4. Repository ထဲက Actions tab ကိုဖွင့်ပါ။ “Build AK Hardware POS APK” ကိုရွေးပြီး Run workflow ကိုနှိပ်ပါ။
5. အစိမ်းရောင် ✓ ပြပြီး build ပြီးသွားလျှင် run ထဲဝင်ပါ။ အောက်ဆုံး Artifacts မှ “AK-Hardware-POS-APK” ကို Download လုပ်ပါ။
6. ZIP ကိုဖြည်ပြီး app-debug.apk ကို Android ဖုန်းမှာဖွင့်၍ Install လုပ်ပါ။ Android က ခွင့်ပြုချက်တောင်းလျှင် ဒီဖိုင်မန်နေဂျာ/Browser အတွက် Install unknown apps ကို ခွင့်ပြုရနိုင်သည်။

မှတ်ချက်များ:
- APK သည် debug APK ဖြစ်သည်။ Play Store တင်ရန် သီးခြား signing လိုသည်။
- ဒီ APK က HTML POS ကို Android WebView ထဲတွင် ဖွင့်ပေးသည်; browser local storage ашиглана. Энэ build нь cloud sync биш. Сүлжээний cloud sync-ийг тусад нь тохируулах шаардлагатай.
- Build хийхэд GitHub Actions интернет ашиглана. Build бүтэлгүйтвэл Actions логийг шалгана уу.
